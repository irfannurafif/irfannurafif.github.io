---
layout: resume
---
## Currently

Current Position Description

## Education

`1990 - 1994`
__University Name__
Degree Awarded

`1995 - 1997`
__University Name__
Degree Awarded 

## Awards

`2012`
Name of Award, Organization 

## Publications

<!-- A list is also available [online](https://scholar.google.co.uk/citations?user=LTOTl0YAAAAJ) -->

### Journals

`1994`
Article Title, Journal Title

`1994`
Article Title, Journal Title

### Books

`1994`
Book Title, Journal Title

`1994`
Book Title, Journal Title


## Presentations

`1994`
Presentation Title, Conference, <a href="https://MyWebsite.tld/presentation1">Link to Presentation</a>


## Occupation

`Current`
__Current Job Title__, Current Employer 

- Task
- Task

`1994-1996`
__Current Job Title__, Current Employer 

- Task
- Task



<!-- ### Footer

Last updated: May 2013 -->


